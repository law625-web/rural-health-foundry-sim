# Placeholder for Pydantic data models

# Example:
# from pydantic import BaseModel
# class CountyData(BaseModel):
#     fips: str
#     state: str
#     broadband_access: float
#     health_outcome_score: float